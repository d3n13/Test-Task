package ru.bilenkod.login3in1testjava.login

import android.app.Activity
import android.content.Intent
import ru.bilenkod.login3in1testjava.login.apis.ApiHolder
import ru.bilenkod.login3in1testjava.login.apis.LoginApi

class LoginProvider : LoginApi {

    private val apiHolder: ApiHolder = ApiHolder()

    override var authState: AuthState = AuthState()
        get() = apiHolder.authState

    var isLoggedIn = apiHolder.isLoggedIn
    var userAvatarUrl = apiHolder.userAvatarUrl
    var userName = apiHolder.userName

    override fun logout() {
        apiHolder.logout()
    }

    fun handleOnActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        apiHolder.signInResult(requestCode, resultCode, data)
    }

    override fun initLoginFrom(activity: Activity) {
        apiHolder.initLoginFrom(activity)
    }

    override fun signInResult(requestCode: Int, resultCode: Int, data: Intent?) {
        apiHolder.signInResult(requestCode, resultCode, data)
    }

    override fun checkLogin() {
        apiHolder.checkLogin()
    }

    fun initLoginViaFrom(apiKey: Int, activity: Activity) {
        apiHolder.swapCurrentApi(apiKey)
        apiHolder.initLoginFrom(activity)
    }
}