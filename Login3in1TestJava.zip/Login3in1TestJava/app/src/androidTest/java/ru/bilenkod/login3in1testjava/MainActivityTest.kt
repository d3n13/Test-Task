package ru.bilenkod.login3in1testjava

import android.content.ComponentName
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.intent.Intents.intended
import androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.vk.sdk.VKServiceActivity
import org.junit.Test
import org.junit.runner.RunWith
import ru.bilenkod.login3in1testjava.ui.activities.MainActivity
import androidx.test.rule.ActivityTestRule
import org.junit.Rule




@RunWith(AndroidJUnit4::class)
class MainActivityTest {

    @Rule
    var menuActivityTestRule = ActivityTestRule(MainActivity::class.java, true, true)

    @Test
    fun vkLoginBtn_isOpeningLoginActivity() {

        onView(withId(R.id.loginViaVk))
                .perform(click())
        intended(hasComponent(ComponentName(InstrumentationRegistry.getInstrumentation().targetContext, VKServiceActivity::class.java)))
    }

}