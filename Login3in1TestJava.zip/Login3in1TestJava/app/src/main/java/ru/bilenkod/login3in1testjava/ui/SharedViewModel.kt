package ru.bilenkod.login3in1testjava.ui

import android.app.Activity
import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.paging.LivePagedListBuilder
import androidx.paging.PagedList
import ru.bilenkod.login3in1testjava.data.githubusersearch.model.GitHubUser
import ru.bilenkod.login3in1testjava.data.githubusersearch.source.SearchDataSourceFactory
import ru.bilenkod.login3in1testjava.data.githubusersearch.source.SearchDataSource
import java.util.*

class SharedViewModel(appCtx: Application = App.instance) : AndroidViewModel(appCtx) {

    companion object {
        const val SEARCH_DELAY: Short = 600
    }

    private var loginProvider = App.loginProvider
    private var searchString: String = ""

    private var timer: Timer? = null
    private var timerTask: TimerTask? = null
    private var factory: SearchDataSourceFactory? = null

    var isLoggedIn = loginProvider.isLoggedIn
    var imageUrl = loginProvider.userAvatarUrl
    var userName = loginProvider.userName

    var usersList: LiveData<PagedList<GitHubUser>> = object :
            LiveData<PagedList<GitHubUser>>() {}

    init {
        setToDefaultState()
    }

    private fun setToDefaultState() {
        searchGitHub("")
    }

    private fun searchGitHub(keyword: String) {
        if (factory == null) {
            factory = SearchDataSourceFactory(keyword)
        } else {
            factory!!.invalidateDataSourceIfKeywordIsUpdated(keyword)
        }

        val config = PagedList.Config.Builder()
                .setPageSize(SearchDataSource.PAGE_SIZE)
                .setEnablePlaceholders(false)
                .build()

        usersList = LivePagedListBuilder(factory!!, config).build()
    }

    fun initSearchTaskWithDelay(searchString: String, delay: Int) {
        this.searchString = searchString
        if (timer == null && timerTask == null) {
            timerTask = object : TimerTask() {
                override fun run() {
                    searchGitHubTimerTask()
                }
            }
            timer = Timer()
            timer?.schedule(timerTask, delay.toLong())
        } else if (delay == 0) {
            nullTimerAndTask()
            initSearchTaskWithDelay(searchString, delay)
        }
    }

    fun searchGitHubTimerTask() {
        searchGitHub(searchString)
        nullTimerAndTask()
    }

    private fun nullTimerAndTask() {
        timerTask?.cancel()
        timer?.cancel()
        timer?.purge()
        timerTask = null
        timer = null
    }


    fun handleOnActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        loginProvider.handleOnActivityResult(requestCode, resultCode, data)
    }

    fun logout() {
        loginProvider.logout()
    }

    fun initLoginViaFrom(apiKey: Int, activity: Activity) {
        loginProvider.initLoginViaFrom(apiKey, activity)
    }
}